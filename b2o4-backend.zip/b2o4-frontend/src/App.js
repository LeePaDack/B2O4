import logo from './logo.svg';
import './App.css';
import GalleryUpload from './components/GalleyUpload';

function App() {
  return (
    <div className="App">
      <GalleryUpload />
    </div>
  );
}

export default App;
