package b2o4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class B2o4BackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
