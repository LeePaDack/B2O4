package b2o4.dto;

import lombok.*;

@Getter
@Setter
@ToString
public class GalleryBoard {
	private int GBPostNo;
	private String GBPostTitle;
	private String GBPostContent;
	private String GBImages;
	private String GBPostCreateDate;
	
}
