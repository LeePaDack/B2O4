package b2o4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class B2o4BackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(B2o4BackendApplication.class, args);
	}

}
